<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Register Form</title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/css/style.css">
  </head>
  <body>
    <form class="signup-form" action="<?php echo site_url('Register/savingdata'); ?>" method="post" enctype="multipart/form-data">

      <!-- form header --> 
      <div class="form-header">
        <h1>Register New Admin</h1>
      </div>

      <!-- form body -->
      <div class="form-body">

        <!-- Firstname and Lastname -->
        <div class="horizontal-group">
          <div class="form-group left">
            <label for="firstname" class="label-title">User name *</label>
            <input type="text" name="username" class="form-input" placeholder="enter your first name" required="required" />
          </div>

        <!-- Email and phone number -->
        <div class="horizontal-group">
          <div class="form-group right">
          <label for="email" class="label-title">Email*</label>
          <input type="email" name="email" class="form-input" placeholder="enter your email" required="required">
          </div>

           <!-- Firstname and Lastname -->
        <div class="horizontal-group">
          <div class="form-group left">
            <label for="phone" class="label-title"> Phone No*</label>
            <input type="text" name="phone_no" class="form-input" placeholder="enter your phone number" required="required" />
          </div>

        <!-- Email and phone number -->
        <div class="horizontal-group">
          <div class="form-group right">
          <label for="address" class="label-title">Address*</label>
          <input type="text" name="address" class="form-input" placeholder="enter your address" required="required">
          </div>

        <!-- Passwrod and confirm password -->
        <div class="horizontal-group">
          <div class="form-group ">
            <label for="password" class="label-title">Password *</label>
            <input type="password" name="password" class="form-input" placeholder="enter your password" required="required">
          </div>
         

        <!-- Profile picture and project -->
        <div class="horizontal-group">
          <div class="form-group left" >
            <label for="choose-file" class="label-title">Upload Profile Picture</label>
            <input type="file" id="choose-file" name="profile_image" size="33"  accept=".jpg, .png">
          </div>

      <!-- form-footer -->
      <div class="form-footer">
        <button type="submit" class="btn">Register</button>
      </div>

    </form>

  </body>
</html>