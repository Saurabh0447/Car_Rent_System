<!DOCTYPE html>
<html lang="en"> 
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>static/css/login.css" />
</head>
<body>
<!-- -->
<div class="container">

  <section id="content">
    <form action="<?php echo site_url('register/auth'); ?>" method="post">
      <h1>Login Form</h1>
      <div>
        <input type="email" placeholder="Email" name="email" required="" id="email" />
      </div>
      <div>
        <input type="password" placeholder="Password" name="password" required="" id="password" />
      </div>
      <div>
        <input type="submit" value="Log in" />
      </div>
    </form><!-- form -->
    
  </section><!-- content -->
</div><!-- container -->
</body>
</html>