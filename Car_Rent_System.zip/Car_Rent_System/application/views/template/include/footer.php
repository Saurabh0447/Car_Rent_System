
        <!-- partial -->
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <script src="<?php echo base_url(); ?>static/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url(); ?>static/vendors/chartjs/Chart.min.js"></script>
  <script src="<?php echo base_url(); ?>static/vendors/jvectormap/jquery-jvectormap.min.js"></script>
  <script src="<?php echo base_url(); ?>static/vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url(); ?>static/dashboardjs/material.js"></script>
  <script src="<?php echo base_url(); ?>static/dashboardjs/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url(); ?>static/dashboardjs/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>
</html> 