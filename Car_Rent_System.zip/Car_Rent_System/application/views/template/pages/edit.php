<head>
<link rel="stylesheet" href="<?php echo base_url(); ?>static/css/dashboard/addcar.css">
</head>
<body>
    <!--  -->
<div class="form-style-8">
<form action="<?php echo site_url('welcome/update/'.$id); ?>" method="post">
<input type="hidden" name="id"   value='<?php echo $id ?>'/>
    <input type="text" name="car_name" placeholder="Enter Car Name"  value='<?php echo $car_name ?>'/>
    <input type="text" name="car_model" placeholder="Enter Car Model" value="<?php echo $car_model?>"/>
    <input type="text" name="car_price" placeholder="Enter Car Price" value="<?php echo $car_price?>"/>
    <input type="file" name="img" id="" value="<?php echo $img?>"><br>
    <img src="<?php echo $img?>"  alt="NO IMAGE"/><br>
    <!-- <input type="button" value="Add a Car" /> -->
    <button id="addcar" type="submit">Update car</button>
  </form>
</div>
<script type="text/javascript">
//auto expand textarea
function adjust_textarea(h) {
    h.style.height = "20px";
    h.style.height = (h.scrollHeight)+"px";
}
</script>
</body>
</html>
                  