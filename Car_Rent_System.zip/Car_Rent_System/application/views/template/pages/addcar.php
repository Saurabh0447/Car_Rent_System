<head>
<link rel="stylesheet" href="<?php echo base_url(); ?>static/css/dashboard/addcar.css">
</head>
<body>
<div class="form-style-8">
  <form action="<?php echo site_url('welcome/savecar'); ?>" method="post" enctype="multipart/form-data">
    <input type="text" name="name" placeholder="Enter your Name" />
    <input type="email" name="email" placeholder="Enter your email" />
    <input type="text" name="phone_no" placeholder="Enter your phone no" />
    <input type="text" name="car_name" placeholder="Enter Car Name" />
    <input type="text" name="car_model" placeholder="Enter Car Model" />
    <input type="text" name="car_price" placeholder="Enter Car Price" />
    <label for="drli">Driving License</label><br>
    <input type="file" name="drli" id=""><br>
    <label for="img">Car Image</label><br>
    <input type="file" name="img" id=""><br>
    <div style="padding-top: 7px ">
    <button id="addcar" type="submit">Add car</button>
    </div>
  </form>
</div>
<script type="text/javascript">
//auto expand textarea
function adjust_textarea(h) {
    h.style.height = "20px";
    h.style.height = (h.scrollHeight)+"px";
}
</script>
</body>
</html>