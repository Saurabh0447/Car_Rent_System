


<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('<?php echo base_url(); ?>static/page/images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Services <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Our Services</h1>
          </div>
        </div>
      </div>
    </section>
    

<div class="container" style="padding:10px  ">
  <form action="<?php echo site_url('profile/addmorecar'); ?>" method="post" enctype="multipart/form-data">
  <div class="form-group">
      <label style="color:black;" for="name">Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter your Name" name="name">
    </div>
    <div class="form-group">
      <label style="color:black;" for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter your email" name="email">
    </div>
    <div class="form-group">
      <label style="color:black;" for="phone">Phone NO:</label>
      <input type="text" class="form-control" id="phone" placeholder="Enter Phone number" name="phone_no">
    </div>
    <div class="form-group">
      <label style="color:black;" for="phone">Car Name:</label>
      <input type="text" class="form-control" placeholder="Enter Car Name" name="car_name">
    </div>
    <div class="form-group">
      <label style="color:black;" for="phone">Car Model:</label>
      <input type="text" class="form-control"  placeholder="Enter Your Car Number" name="car_model">
    </div>
    <div class="form-group">
      <label style="color:black;" for="phone">Car Price:</label>
      <input type="text" class="form-control"  placeholder="Enter Your Car Price" name="car_price">
    </div>
    <div class="form-group">
      <label style="color:black;" for="dl">Driving License:</label>
      <input type="File" class="form-control" name="drli">
    </div>
    <div class="form-group">
      <label style="color:black;" for="id">Image:</label>
      <input type="file" class="form-control" name="img">
    </div>
    <button type="submit" class="btn btn-secondary">Submit</button>
  </form>
</div>
