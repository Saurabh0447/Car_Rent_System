
    <!-- END nav -->
    
	
	
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $(function(){
            var dtToday = new Date();
            var month = dtToday.getMonth() + 1;
            var day = dtToday.getDate();
            var year = dtToday.getFullYear();
            if(month < 10)
                month = '0' + month.toString();
            if(day < 10)
                day = '0' + day.toString();
            
            var minDate= year + '-' + month + '-' + day;
            
            $('#txtDate').attr('min', minDate);
			$('#txtData').attr('min',minDate);
        });
        </script>

    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('<?php echo base_url(); ?>static/page/images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Car details <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Car Details</h1>
          </div>
        </div>
      </div>
    </section>
		

		<section class="ftco-section ftco-car-details">
      <div class="container">
      	<div class="row justify-content-center">
		  <?php echo $id;?>
				<div class='col-md-12'>
      			<div class='car-details'>
      			<div class='img rounded' style='background-image: url(<?php echo $img?>);'></div>
      				<div class='text text-center'>
      					<span class='subheading'><?php echo $car_name ?></span>
						 	<h2><?php echo $car_model?></h2>
      				</div>
      			</div>
      		</div>
      	</div>
      	
		  <div class="col-md-4 d-flex align-items-center">
	  						<form action="<?php echo site_url('layout/book'); ?>" method="POST" class="request-form ftco-animate bg-primary">
		          		<h2>Make your trip</h2>
						  <?php   echo array_key_exists("email", $_SESSION) ?
								"<div class='form-group'>
								<input type='hidden' name='name' class='form-control' value='$user->username'>
								<input type='hidden' name='email' class='form-control' value='$user->email' >
							     </div>"
										:	"<h3 style='color:black;'>Please Login First</h3>"
								?>
								<div class="form-group">
			    					<input type="hidden" name="car_name" class="form-control" value="<?php echo $car_name ?>" >
			    					<input type="hidden" name="car_model" class="form-control" value="<?php echo $car_model?>" >
									<input type="hidden" name="car_price" class="form-control" value="<?php echo $car_price?>" >
								</div>
								<div class="form-group">
			    					<label for="" class="label">Pick-up location</label>
			    					<input type="text" name="pick_up" class="form-control" placeholder="City, Airport, Station, etc">
			    				</div>
			    				<div class="form-group">
			    					<label for="" class="label">Drop-off location</label>
			    					<input type="text" name="drop_off" class="form-control" placeholder="City, Airport, Station, etc">
			    				</div>
			    				<div class="d-flex">
			    					<div class="form-group mr-2">
			                <label for="" class="label">Pick-up date</label>
			                <input type="date" name="pick_date" class="form-control" id="txtDate" placeholder="Date">
			              </div>
			              <div class="form-group ml-2">
			                <label for="" class="label">Drop-off date</label>
			                <input type="date" name="drop_date" class="form-control" id="txtData" placeholder="Date">
			              </div>
		              </div>
		              <div class="form-group">
		                <label for="" class="label">Pick-up time</label>
		                <input type="text" name="time" class="form-control" id="time_pick" placeholder="Time">
		              </div>
						<?php   echo array_key_exists("email", $_SESSION) ?
								"<div class='form-group'>
								<button type='submit' value='Rent A Car Now' class='btn btn-secondary py-3 px-4'>Rent A Car Now</button>
							     </div>"
										:	"<div class='form-group'>
											</div>"
								?>
						</form>
	  					</div>
    
</div>
