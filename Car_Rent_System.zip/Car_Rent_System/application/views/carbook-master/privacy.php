<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('<?php echo base_url(); ?>static/page/images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Car details <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Privacy and Policy</h1>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-about">
			<div class="container">
				<div class="row no-gutters">
					<div class="col-md-6 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/about.jpg);">
					</div>
					<div class="col-md-6 wrap-about ftco-animate">
	          <div class="heading-section heading-section-white pl-md-5">
	          	<span class="subheading">Privacy</span>
	            <h2 class="mb-4">Privacy &amp; Cookies Policy</h2>

	            <p>This privacy policy is an electronic record in the form of an electronic contract formed under the information technology act, 2000, and the rules made thereunder and the amended provisions pertaining to electronic documents/records in various statutes as amended by the information technology act, 2000. This privacy policy does not require any physical, electronic or digital signature.</p>
	            <p>This document is published and shall be construed in accordance with the provisions of the information technology (reasonable security practices and procedures and sensitive personal data of information) rules, 2011 under information technology act, 2000; that require publishing of the privacy policy for the collection, use, storage and transfer of sensitive personal data or information.</p>
	            <p>Please read this privacy policy carefully. By using the website, you indicate that you understand, agree, and consent to this privacy policy.</p>
	          </div>
					</div>
				</div>
			</div>
		</section>