
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('<?php echo base_url(); ?>static/page/images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Pricing <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Pricing</h1>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<div class="car-list">
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr class="text-center">
						        <th>&nbsp;</th>
						        <th>&nbsp;</th>
						        <th class="bg-primary heading">Per Day Rate</th>
						      </tr>
						    </thead>
						    <tbody>
							<?php
                      //echo $result;
                          $i=1;
                          foreach($data as $row){

				echo "<tr class=''>
				<td class='car-image'><div class='img' style='background-image:url($row->img );'></div></td>
			  <td class='product-name'>
				  <h2>$row->car_name</h2>
				  <h5>$row->car_model</h5s>
			  </td>
			  
			  <td class='price'>
				  <p class='btn-custom'><a href='./car_single".$row->id."'>Rent a car</a></p>
				  <div class='price-rate'>
					  <h3>
						  <span class='num'><small class='currency'>$</small>$row->car_price</span>
						  <span class='per'>/per day</span>
					  </h3>
				  </div>
			  </td>
			  ";
                          $i++;
                          }
                      ?>
						      <!-- END TR-->
						    </tbody>
						  </table>
					  </div>
    			</div>
    		</div>
			</div>
		</section>

