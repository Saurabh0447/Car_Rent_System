<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Carbook - Most trusted car rental website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/animate.css">
    
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/magnific-popup.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/aos.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/ionicons.min.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/icomoon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>static/page/css/style.css">
    <script>
    $('.nav-link').on('click', function(){
      $('.nav-link').removeClass('saurabh');
      $(this).addClass('saurabh');
      });
    </script>
  </head>
  <body>

  
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="<?php echo base_url(); ?>layout/dashboard">Car<span>Book</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="./" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="<?php echo base_url(); ?>layout/about" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="<?php echo base_url(); ?>layout/services" class="nav-link">Services</a></li>
	          <li class="nav-item"><a href="<?php echo base_url(); ?>layout/pricing" class="nav-link">Pricing</a></li>
	          <li class="nav-item"><a href="<?php echo base_url(); ?>layout/car" class="nav-link">Cars</a></li>
	          <li class="nav-item"><a href="<?php echo base_url(); ?>layout/contact" class="nav-link">Contact</a></li>
			  <div class="right">
         
      <?php   echo array_key_exists("email", $_SESSION) ?
       "<button class='login_btn'>$user->username</button><a href='./logout' ><button class='login_btn'>logout</button></a>"
			:	"<a href='layout/login' ><button class='login_btn'>Log In</button></a>"
			
       ?>
        </div>
	        </ul>
	      </div>
	    </div>
	  </nav>
    
