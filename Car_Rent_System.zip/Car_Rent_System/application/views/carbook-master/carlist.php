
	<section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row">
				<?php
				$i=1;
				foreach($data as $row){
    			echo "<div class='col-md-4'>
				<div class='car-wrap rounded ftco-animate'>
				<div class='img rounded d-flex align-items-end' style='background-image: url($row->img);'>
				</div>
				<div class='text'>
				<h2 class='mb-0'><a href='./car-single'>$row->car_name</a></h2>
				<div class='d-flex mb-3'>
				<span class='cat'>$row->car_model</span>
				<p class='price ml-auto'>$row->car_price<span>/day</span></p>
				</div>
				<p class='d-flex mb-0 d-block'> <a href='./car_single".$row->id."' class='btn btn-secondary py-2 ml-1'>Details</a></p>
				</div>
    			</div>
    			</div>";
				$i++;
				}
				?>
    		</div>
    </section>